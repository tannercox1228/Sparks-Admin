package com.example.hookup4u_admin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
